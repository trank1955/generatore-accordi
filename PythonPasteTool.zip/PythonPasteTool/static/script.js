// Guitar chord generator JavaScript

document.addEventListener('DOMContentLoaded', function() {
    const generateBtn = document.getElementById('generateBtn');
    const keySelect = document.getElementById('keySelect');
    const styleSelect = document.getElementById('styleSelect');
    const rhythmSelect = document.getElementById('rhythmSelect');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const resultsCard = document.getElementById('resultsCard');
    const emptyState = document.getElementById('emptyState');
    const chordsContainer = document.getElementById('chordsContainer');
    const progressionTitle = document.getElementById('progressionTitle');
    const downloadPdfBtn = document.getElementById('downloadPdfBtn');
    const scaleSelect = document.getElementById('scaleSelect');
    const scaleNotesDisplay = document.getElementById('scaleNotesDisplay');
    const scaleNotesContainer = document.getElementById('scaleNotesContainer');
    const saveProgressionBtn = document.getElementById('saveProgressionBtn');
    const viewSavedBtn = document.getElementById('viewSavedBtn');
    const saveProgressionModal = new bootstrap.Modal(document.getElementById('saveProgressionModal'));
    const savedProgressionsModal = new bootstrap.Modal(document.getElementById('savedProgressionsModal'));
    const progressionNameInput = document.getElementById('progressionName');
    const confirmSaveBtn = document.getElementById('confirmSaveBtn');
    const savedProgressionsList = document.getElementById('savedProgressionsList');

    // Store current progression data for PDF download and saving
    let currentProgressionData = null;

    generateBtn.addEventListener('click', generateProgression);
    downloadPdfBtn.addEventListener('click', downloadPdf);
    saveProgressionBtn.addEventListener('click', showSaveModal);
    viewSavedBtn.addEventListener('click', showSavedProgressions);
    confirmSaveBtn.addEventListener('click', saveCurrentProgression);

    async function generateProgression() {
        // Get selected values
        const key = keySelect.value;
        const scale = scaleSelect.value;
        const style = styleSelect.value;
        const rhythm = rhythmSelect.value;

        // Show loading state
        showLoading();

        try {
            const response = await fetch('/generate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    key: key,
                    scale: scale,
                    style: style,
                    rhythm: rhythm
                })
            });

            if (!response.ok) {
                throw new Error('Errore nella generazione della progressione');
            }

            const data = await response.json();
            
            // Store data for PDF download
            currentProgressionData = {
                key: key,
                scale: scale,
                style: style,
                rhythm: rhythm,
                chords: data.chords,
                scale_notes: data.scale_notes,
                scale_name: data.scale_name
            };
            
            displayResults(data);

        } catch (error) {
            console.error('Error:', error);
            showError('Si è verificato un errore durante la generazione della progressione. Riprova.');
        } finally {
            hideLoading();
        }
    }

    function showLoading() {
        generateBtn.disabled = true;
        generateBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Generazione...';
        loadingSpinner.classList.remove('d-none');
        resultsCard.classList.add('d-none');
        emptyState.classList.add('d-none');
    }

    function hideLoading() {
        generateBtn.disabled = false;
        generateBtn.innerHTML = '<i class="fas fa-magic me-2"></i>🎶 Genera Progressione';
        loadingSpinner.classList.add('d-none');
    }

    function displayResults(data) {
        // Update title
        progressionTitle.innerHTML = `<i class="fas fa-list-music me-2"></i>${data.title}`;
        
        // Display scale notes
        if (data.scale_notes && data.scale_notes.length > 0) {
            scaleNotesContainer.innerHTML = '';
            data.scale_notes.forEach((note, index) => {
                const noteElement = document.createElement('span');
                noteElement.className = 'scale-note';
                noteElement.textContent = note;
                scaleNotesContainer.appendChild(noteElement);
                
                // Add separator except for last note
                if (index < data.scale_notes.length - 1) {
                    const separator = document.createElement('span');
                    separator.className = 'scale-separator';
                    separator.textContent = ' - ';
                    scaleNotesContainer.appendChild(separator);
                }
            });
            scaleNotesDisplay.classList.remove('d-none');
        } else {
            scaleNotesDisplay.classList.add('d-none');
        }
        
        // Clear previous results
        chordsContainer.innerHTML = '';

        // Create chord elements
        data.chords.forEach((chord, index) => {
            const chordElement = createChordElement(chord, index);
            chordsContainer.appendChild(chordElement);
        });

        // Show results
        emptyState.classList.add('d-none');
        resultsCard.classList.remove('d-none');
        
        // Scroll to results
        resultsCard.scrollIntoView({ behavior: 'smooth' });
    }

    function createChordElement(chord, index) {
        const chordDiv = document.createElement('div');
        chordDiv.className = 'chord-item';
        chordDiv.style.animationDelay = `${index * 0.1}s`;

        // Create chord header
        const chordHeader = document.createElement('div');
        chordHeader.className = 'chord-name';
        chordHeader.innerHTML = `
            <i class="fas fa-music"></i>
            ${chord.name}
            <span class="chord-degree">${chord.degree}</span>
        `;

        chordDiv.appendChild(chordHeader);

        // Create tablature section if available
        if (chord.tablature && chord.tablature.length > 0) {
            const tablatureDiv = document.createElement('div');
            tablatureDiv.className = 'tablature';
            
            const tablatureTitle = document.createElement('div');
            tablatureTitle.className = 'tablature-title';
            tablatureTitle.innerHTML = '<i class="fas fa-guitar me-2"></i>Tablatura:';
            tablatureDiv.appendChild(tablatureTitle);

            chord.tablature.forEach(line => {
                const lineDiv = document.createElement('div');
                lineDiv.className = 'tablature-line';
                lineDiv.textContent = line;
                tablatureDiv.appendChild(lineDiv);
            });

            chordDiv.appendChild(tablatureDiv);
        } else {
            // Show message if no tablature available
            const noTabDiv = document.createElement('div');
            noTabDiv.className = 'text-muted mt-2';
            noTabDiv.innerHTML = '<i class="fas fa-exclamation-circle me-2"></i>Tablatura non disponibile per questo accordo';
            chordDiv.appendChild(noTabDiv);
        }

        return chordDiv;
    }

    function showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'alert alert-danger alert-dismissible fade show';
        errorDiv.innerHTML = `
            <i class="fas fa-exclamation-triangle me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        const container = document.querySelector('.container');
        container.insertBefore(errorDiv, container.firstChild);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            if (errorDiv.parentNode) {
                errorDiv.remove();
            }
        }, 5000);
    }

    // PDF download function
    async function downloadPdf() {
        if (!currentProgressionData) {
            showError('Nessuna progressione da scaricare. Genera prima una progressione.');
            return;
        }

        try {
            downloadPdfBtn.disabled = true;
            downloadPdfBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Generando PDF...';

            const response = await fetch('/download-pdf', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(currentProgressionData)
            });

            if (!response.ok) {
                throw new Error('Errore nella generazione del PDF');
            }

            // Download the PDF
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = url;
            
            // Get filename from response headers or generate one
            const disposition = response.headers.get('Content-Disposition');
            let filename = 'progressione.pdf';
            if (disposition && disposition.includes('filename=')) {
                filename = disposition.split('filename=')[1].replace(/"/g, '');
            }
            
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);

            // Show success message
            showSuccess('PDF scaricato con successo!');

        } catch (error) {
            console.error('Error downloading PDF:', error);
            showError('Si è verificato un errore durante il download del PDF. Riprova.');
        } finally {
            downloadPdfBtn.disabled = false;
            downloadPdfBtn.innerHTML = '<i class="fas fa-download me-2"></i>Scarica PDF';
        }
    }

    function showSuccess(message) {
        const successDiv = document.createElement('div');
        successDiv.className = 'alert alert-success alert-dismissible fade show';
        successDiv.innerHTML = `
            <i class="fas fa-check-circle me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        const container = document.querySelector('.container');
        container.insertBefore(successDiv, container.firstChild);
        
        // Auto-dismiss after 3 seconds
        setTimeout(() => {
            if (successDiv.parentNode) {
                successDiv.remove();
            }
        }, 3000);
    }

    // Save progression functions
    function showSaveModal() {
        if (!currentProgressionData) {
            showError('Nessuna progressione da salvare. Genera prima una progressione.');
            return;
        }
        
        // Generate default name
        const defaultName = `${currentProgressionData.style.charAt(0).toUpperCase() + currentProgressionData.style.slice(1)} - ${currentProgressionData.key} ${currentProgressionData.scale}`;
        progressionNameInput.value = defaultName;
        saveProgressionModal.show();
    }

    async function saveCurrentProgression() {
        if (!currentProgressionData) {
            showError('Nessuna progressione da salvare.');
            return;
        }

        const name = progressionNameInput.value.trim();
        if (!name) {
            showError('Inserisci un nome per la progressione.');
            return;
        }

        try {
            confirmSaveBtn.disabled = true;
            confirmSaveBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Salvando...';

            const saveData = {
                ...currentProgressionData,
                name: name
            };

            const response = await fetch('/save-progression', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(saveData)
            });

            const result = await response.json();

            if (response.ok) {
                showSuccess(result.message);
                saveProgressionModal.hide();
            } else {
                showError(result.error || 'Errore nel salvataggio');
            }

        } catch (error) {
            console.error('Error saving progression:', error);
            showError('Errore di connessione durante il salvataggio.');
        } finally {
            confirmSaveBtn.disabled = false;
            confirmSaveBtn.innerHTML = '<i class="fas fa-save me-2"></i>Salva';
        }
    }

    // View saved progressions
    async function showSavedProgressions() {
        try {
            savedProgressionsList.innerHTML = '<div class="text-center"><i class="fas fa-spinner fa-spin"></i> Caricamento...</div>';
            savedProgressionsModal.show();

            const response = await fetch('/saved-progressions');
            const data = await response.json();

            if (data.progressions && data.progressions.length > 0) {
                renderSavedProgressions(data.progressions);
            } else {
                savedProgressionsList.innerHTML = `
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-music fa-3x mb-3"></i>
                        <h5>Nessuna progressione salvata</h5>
                        <p>Le progressioni che salvi appariranno qui</p>
                    </div>
                `;
            }

        } catch (error) {
            console.error('Error loading saved progressions:', error);
            savedProgressionsList.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Errore nel caricamento delle progressioni salvate
                </div>
            `;
        }
    }

    function renderSavedProgressions(progressions) {
        savedProgressionsList.innerHTML = '';

        progressions.forEach(progression => {
            const progressionElement = createSavedProgressionElement(progression);
            savedProgressionsList.appendChild(progressionElement);
        });
    }

    function createSavedProgressionElement(progression) {
        const div = document.createElement('div');
        div.className = 'card mb-3';
        
        const createdDate = new Date(progression.created_at).toLocaleDateString('it-IT');
        const chords = progression.chords_data.map(c => c.name).join(', ');

        div.innerHTML = `
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start">
                    <div class="flex-grow-1">
                        <h6 class="card-title mb-1">
                            ${progression.name}
                            ${progression.is_favorite ? '<i class="fas fa-heart text-warning ms-2"></i>' : ''}
                        </h6>
                        <p class="card-text text-muted small mb-2">
                            ${progression.key_signature} ${progression.scale_type} - ${progression.style} - ${progression.rhythm}
                        </p>
                        <p class="card-text small mb-2">
                            <strong>Accordi:</strong> ${chords}
                        </p>
                        <small class="text-muted">
                            <i class="fas fa-calendar me-1"></i>${createdDate}
                            <i class="fas fa-repeat ms-3 me-1"></i>Generata ${progression.times_generated} volte
                        </small>
                    </div>
                    <div class="btn-group-vertical btn-group-sm ms-3">
                        <button class="btn btn-outline-primary btn-sm" onclick="loadProgression(${progression.id})">
                            <i class="fas fa-play"></i>
                        </button>
                        <button class="btn btn-outline-warning btn-sm" onclick="toggleFavorite(${progression.id}, ${progression.is_favorite})">
                            <i class="fas fa-heart"></i>
                        </button>
                        <button class="btn btn-outline-danger btn-sm" onclick="deleteProgression(${progression.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;

        return div;
    }

    // Global functions for saved progression actions
    window.loadProgression = async function(id) {
        try {
            const response = await fetch(`/progression/${id}`);
            const progression = await response.json();

            if (response.ok) {
                // Set form values
                keySelect.value = progression.key_signature;
                scaleSelect.value = progression.scale_type;
                styleSelect.value = progression.style;
                rhythmSelect.value = progression.rhythm;

                // Create display data
                const displayData = {
                    title: `${progression.style.charAt(0).toUpperCase() + progression.style.slice(1)} – ${progression.key_signature} ${progression.scale_type}`,
                    scale_notes: progression.scale_notes,
                    scale_name: `${progression.key_signature} ${progression.scale_type}`,
                    chords: progression.chords_data
                };

                // Store current data
                currentProgressionData = {
                    key: progression.key_signature,
                    scale: progression.scale_type,
                    style: progression.style,
                    rhythm: progression.rhythm,
                    chords: progression.chords_data,
                    scale_notes: progression.scale_notes,
                    scale_name: displayData.scale_name
                };

                // Display results
                displayResults(displayData);
                savedProgressionsModal.hide();
                showSuccess('Progressione caricata');

            } else {
                showError(progression.error || 'Errore nel caricamento');
            }

        } catch (error) {
            console.error('Error loading progression:', error);
            showError('Errore di connessione');
        }
    };

    window.toggleFavorite = async function(id, currentFavorite) {
        try {
            const response = await fetch(`/progression/${id}/favorite`, {
                method: 'POST'
            });
            const result = await response.json();

            if (response.ok) {
                showSuccess(result.message);
                showSavedProgressions(); // Refresh the list
            } else {
                showError(result.error || 'Errore nell\'aggiornamento');
            }

        } catch (error) {
            console.error('Error toggling favorite:', error);
            showError('Errore di connessione');
        }
    };

    window.deleteProgression = async function(id) {
        if (!confirm('Sei sicuro di voler eliminare questa progressione?')) {
            return;
        }

        try {
            const response = await fetch(`/progression/${id}`, {
                method: 'DELETE'
            });
            const result = await response.json();

            if (response.ok) {
                showSuccess(result.message);
                showSavedProgressions(); // Refresh the list
            } else {
                showError(result.error || 'Errore nell\'eliminazione');
            }

        } catch (error) {
            console.error('Error deleting progression:', error);
            showError('Errore di connessione');
        }
    };

    // Add keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey && e.key === 'Enter') {
            e.preventDefault();
            generateProgression();
        }
        if (e.ctrlKey && e.key === 'd' && currentProgressionData) {
            e.preventDefault();
            downloadPdf();
        }
        if (e.ctrlKey && e.key === 's' && currentProgressionData) {
            e.preventDefault();
            showSaveModal();
        }
        if (e.ctrlKey && e.key === 'h') {
            e.preventDefault();
            showSavedProgressions();
        }
    });
});
